package com.account.cl.account.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.cl.account.model.Account;
import com.account.cl.account.repository.AccountRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class AccountService {

    @Autowired
    private AccountRepository repoAccount;


    public List<Account> findAll(Account account){
        //buscas por id y si el usuario tiene el rol administrador le devuelvo el return
        //y si no es administrador le lanzo un mensaje de error "no tiene permiso"
        if ("admin".equalsIgnoreCase(account.getRole())) {
            return repoAccount.findAll();
        } else { 
            throw new SecurityException("No tiene permisos para ver esta información");
        }
    }
    
    


    //search account by ID
    public Account findbyId(long id){
        return repoAccount.findById(id).get();
    }

    //save account
    public Account save(Account account) {
        return repoAccount.save(account);
    }

    //search account by mail
    public Account findByMail(String mail) {
        return repoAccount.findByMail(mail).orElse(null);
    }

    public void eliminate(Long id) {
        repoAccount.deleteById(id);
    }
    

    

    public List<Account> findByRole(String role) {
        return repoAccount.findByRole(role);
    }

}
