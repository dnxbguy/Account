package com.account.cl.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.account.cl.account.model.Account;
import com.account.cl.account.repository.AccountRepository;
import com.account.cl.account.service.AccountService;

import io.micrometer.core.ipc.http.HttpSender.Response;

import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/v1/account")
public class AccountController {

    private final AccountRepository accountRepository;

    @Autowired
    private AccountService serviceAccount;

    AccountController(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<Account> getIDString(@PathVariable int id) {
        try {
            Account account = serviceAccount.findbyId(id);
            return ResponseEntity.ok(account);
            //return serviceAccount.findbyId(id);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
        
    }

    @GetMapping("/mail/{mail}")
    public ResponseEntity<Account> getByMail(@PathVariable String mail) {
        try {
            Account account = serviceAccount.findByMail(mail);
            //return serviceAccount.findByMail(mail);
            return ResponseEntity.ok(account);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
}   
    @PostMapping
    public ResponseEntity<Account> save(@RequestBody Account account){
    Account saveAccount = serviceAccount.save(account);
    return ResponseEntity.status(HttpStatus.CREATED).body(saveAccount);
}
    
    @GetMapping("/all")
    public List<Account> getAllAccounts(@RequestBody Account account) {
    return serviceAccount.findAll(account); 

    //añadir password, cuando las traiga devuelva encriptada *********
    //añadir roles y diferenciar por roles los usuarios

}
    @GetMapping("/role/{role}")
    public ResponseEntity<List<Account>> getAccountsByRole(@PathVariable String role) {
    try {
        List<Account> accounts = serviceAccount.findByRole(role);
        if (accounts.isEmpty()) {
            return ResponseEntity.noContent().build(); 
        }
        return ResponseEntity.ok(accounts);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}

  
@DeleteMapping("/{id}")
public ResponseEntity<?> eliminar(@PathVariable Long id) {
    try {
        serviceAccount.eliminate(id.intValue()); // convertir explícitamente
        return ResponseEntity.noContent().build();
    } catch (Exception e) {
        return ResponseEntity.notFound().build();
    }
}


}


