package com.account.cl.account.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "account")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Account {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = true)
    private String name;

    @Column(nullable = true)
    private String password;

    @Column(nullable = true)
    private String mail;

    @Column(nullable = true)
    private String direccion;

    @Column(name = "rol", nullable = true)
    private String role;

    
    @Column(name = "fecNac")
    private int dateOfBirthUser;

    @Column(unique = true, length = 13, nullable = false)
    private String rut;

    @Column(unique = true, length = 8, nullable = false)
    private int phoneNumber;

    @Column(name = "fecCrea")
    private int dateCreation;

    

}
