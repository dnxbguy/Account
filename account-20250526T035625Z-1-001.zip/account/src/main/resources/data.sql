Detele from Account;

INSERT INTO account (name, password, mail, direccion, fec_nac, rut, phone_number, fec_crea, rol) VALUES
('Juan Pérez', SHA2('Juan123@perez', 256), 'juan.perez@example.com', 'Calle Falsa 123', 19900315, '12345678-9', 98765432, 20240501, 'Admin'),
('Ana Gómez', SHA2('Ana234@Gomez', 256), 'ana.gomez@example.com', 'Av. Las Rosas 456', 19851123, '23456789-0', 91234567, 20240502, 'Usuario'),
('Carlos Ruiz', SHA2('Carlos345@Ruiz', 256), 'carlos.ruiz@example.com', 'Pje. Los Andes 789', 19790708, '34567890-1', 93456789, 20240503, 'Moderador'),
('María López', SHA2('Maria456@Lopez', 256), 'maria.lopez@example.com', 'Calle 8 N° 154', 19951201, '45678901-2', 94567890, 20240504, 'Usuario'),
('Pedro Soto', SHA2('Pedro567@Soto', 256), 'pedro.soto@example.com', 'Av. Libertad 789', 20010101, '56789012-3', 95678901, 20240505, 'Admin'),
('Laura Díaz', SHA2('Laura678@Diaz', 256), 'laura.diaz@example.com', 'Camino del Inca 321', 19880412, '67890123-4', 96789012, 20240506, 'Moderador'),
('José Vidal', SHA2('Jose789@Vidal', 256), 'jose.vidal@example.com', 'Av. Sur 654', 19731130, '78901234-5', 97890123, 20240507, 'Usuario'),
('Paula Araya', SHA2('Paula890@Araya', 256), 'paula.araya@example.com', 'Pasaje Azul 111', 19990228, '89012345-6', 98901234, 20240508, 'Moderador'),
('Rodrigo Fuentes', SHA2('Rodrigo901@Fuentes', 256), 'rodrigo.fuentes@example.com', 'Calle Larga 222', 19960814, '90123456-7', 99012345, 20240509, 'Usuario'),
('Valentina Ríos', SHA2('Valen012@Rios', 256), 'valentina.rios@example.com', 'Villa Esperanza 987', 20001225, '01234567-8', 90123456, 20240510, 'Admin');








